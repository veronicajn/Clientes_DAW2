 class Alumno {
    constructor(DNI, nombre, notaMedia){
        this.DNI = DNI;
        this.nombre = nombre;
        this.notaMedia = notaMedia;
        this.consultarnota()
        this.cambiarnotamedia()
    }
    consultarnota(){
        alert('El alumno:  ' + this.nombre + " tiene de nota: "+ this.notaMedia);
     }
     cambiarnotamedia(){
         this.notaMedia = 8;
         alert('El alumno:  ' + this.nombre + " tiene una nueva nota de : "+ this.notaMedia);
    
     }
}

 class Colegio {
    constructor(nombre, numAulas, numeroAlumnos){
        this.nombre = nombre;
        this.numAulas = numAulas;
        this.numeroAlumnos = numeroAlumnos;
       /* this.arrayalumno = new Array()


        for (let i = 0; i < arrayalumno.length; i++) {
           this.arrayalumnos[i]= new Alumno(persona)
             
         }*/
        
    }
  
}

let alumno1 = new Alumno(4858,'Rosa',6)

